import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-old-server',
  templateUrl: './old-server.component.html',
  styleUrls: ['./old-server.component.css']
})
export class OldServerComponent {
  oldServerName : string = "Very Very Old Server";

  newOldServerName: string ;
 
}

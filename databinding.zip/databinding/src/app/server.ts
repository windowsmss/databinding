export class Server {
    constructor(
        public serverId: number,
        public serverName: String,
        public serverStatus: String) { }
}

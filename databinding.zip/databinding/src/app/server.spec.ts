import { Server } from './server';

describe('Server', () => {
  it('should create an instance', () => {
    expect(new Server()).toBeTruthy();
  });
});
